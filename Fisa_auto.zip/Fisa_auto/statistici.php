<?php
include 'db.php';

if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$id_v = $_GET['id'];

$v_stmt = $conn->prepare("SELECT * FROM vehicule WHERE id_vehicul = ?");
$v_stmt->bind_param("i", $id_v);
$v_stmt->execute();
$vehicul = $v_stmt->get_result()->fetch_assoc();

$stats_query = "SELECT 
                    SUM(cost_total) as total_spent, 
                    SUM(litri_alimentati) as total_liters, 
                    COUNT(*) as total_entries, 
                    MAX(km_actuali) as current_km, 
                    MIN(km_actuali) as starting_km 
                FROM alimentari WHERE id_vehicul = ?";
$s_stmt = $conn->prepare($stats_query);
$s_stmt->bind_param("i", $id_v);
$s_stmt->execute();
$stats = $s_stmt->get_result()->fetch_assoc();

$total_km = $stats['current_km'] - $stats['starting_km'];
$avg_consumption = ($total_km > 0) ? ($stats['total_liters'] / $total_km) * 100 : 0;
$cost_per_km = ($total_km > 0) ? ($stats['total_spent'] / $total_km) : 0;

$logs = $conn->query("SELECT data_alimentare, km_actuali, litri_alimentati FROM alimentari WHERE id_vehicul = $id_v ORDER BY data_alimentare ASC");
$labels = []; $liters_data = []; $km_labels = [];
while($l = $logs->fetch_assoc()) {
    $labels[] = $l['data_alimentare'];
    $liters_data[] = $l['litri_alimentati'];
    $km_labels[] = $l['km_actuali'];
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Stat Sheet - <?php echo $vehicul['marca']; ?></title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .stat-box { background: #f8f9fa; padding: 15px; border-radius: 8px; border-top: 4px solid #3498db; text-align: center; }
        .stat-box h4 { margin: 0; color: #7f8c8d; font-size: 0.8rem; text-transform: uppercase; }
        .stat-box p { margin: 10px 0 0; font-size: 1.4rem; font-weight: bold; color: #2c3e50; }
    </style>
</head>
<body>
    <header>
        <div style="width: 100px;"></div>
        <h1>Stat Sheet: <?php echo $vehicul['marca'] . " " . $vehicul['model']; ?></h1>
        <button onclick="location.href='index.php'" class="logout-btn" style="background:#7f8c8d;">Înapoi</button>
    </header>

    <main class="container">
        <div class="stats-grid">
            <div class="stat-box">
                <h4>Kilometraj Actual</h4>
                <p><?php echo number_format($stats['current_km'], 0, ',', '.'); ?> KM</p>
            </div>
            <div class="stat-box" style="border-color: #27ae60;">
                <h4>Consum Mediu Total</h4>
                <p><?php echo round($avg_consumption, 2); ?> <small>L/100km</small></p>
            </div>
            <div class="stat-box" style="border-color: #e67e22;">
                <h4>Cost Total Carburant</h4>
                <p><?php echo number_format($stats['total_spent'], 2); ?> <small>RON</small></p>
            </div>
            <div class="stat-box" style="border-color: #9b59b6;">
                <h4>Cost per KM</h4>
                <p><?php echo round($cost_per_km, 2); ?> <small>RON/KM</small></p>
            </div>
        </div>

        <section class="card" style="margin-bottom: 20px;">
            <h3>Specificații Vehicul</h3>
            <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
                <p><strong>VIN:</strong> <?php echo $vehicul['serie_sasiu']; ?></p>
                <p><strong>Nr. Înmatriculare:</strong> <?php echo $vehicul['nr_inmatriculare']; ?></p>
                <p><strong>An Fabricație:</strong> <?php echo $vehicul['an_fabricatie']; ?></p>
                <p><strong>Total Alimentări:</strong> <?php echo $stats['total_entries']; ?></p>
            </div>
        </section>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <section class="card">
                <h3>Istoric Alimentări (Litri)</h3>
                <canvas id="litersChart"></canvas>
            </section>
            <section class="card">
                <h3>Evoluție Kilometraj</h3>
                <canvas id="kmChart"></canvas>
            </section>
        </div>
    </main>

    <script>
        new Chart(document.getElementById('litersChart'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{ label: 'Litri', data: <?php echo json_encode($liters_data); ?>, backgroundColor: '#3498db' }]
            }
        });

        new Chart(document.getElementById('kmChart'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode($labels); ?>,
                datasets: [{ label: 'KM Totali', data: <?php echo json_encode($km_labels); ?>, borderColor: '#27ae60', fill: false }]
            }
        });
    </script>
</body>
</html>