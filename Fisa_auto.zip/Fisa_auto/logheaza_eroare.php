<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$id_vehicul = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_martor = $_POST['id_martor'];
    $descriere = $conn->real_escape_string($_POST['descriere']);
    
    $sql = "INSERT INTO log_erori (id_vehicul, id_martor, descriere_proprietar) VALUES ('$id_vehicul', '$id_martor', '$descriere')";
    if ($conn->query($sql)) { header("Location: index.php"); }
}

$martori = $conn->query("SELECT id_martor, nume_martor FROM martori_bord");
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Logare Defectiune</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header><h1>Raportare Eroare Bord</h1></header>
    <main class="container">
        <section class="card">
            <form method="post">
                <label>Martor Aprins:</label><br>
                <select name="id_martor" required>
                    <?php while($m = $martori->fetch_assoc()): ?>
                        <option value="<?php echo $m['id_martor']; ?>"><?php echo $m['nume_martor']; ?></option>
                    <?php endwhile; ?>
                </select><br><br>
                
                <label>Detalii simptome:</label><br>
                <textarea name="descriere" rows="4" style="width:100%;" required></textarea><br><br>
                
                <button type="submit">Inregistreaza Eroarea</button>
                <button type="button" onclick="location.href='index.php'" style="background:#7f8c8d;">Anulează</button>
            </form>
        </section>
    </main>
</body>
</html>