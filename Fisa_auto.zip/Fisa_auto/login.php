<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $parola = $_POST['parola'];

    $sql = "SELECT id_utilizator, parola FROM utilizatori WHERE email = '$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($parola, $user['parola'])) {
            $_SESSION['user_id'] = $user['id_utilizator'];
            header("Location: index.php");
        } else {
            echo "<p style='color:red;'>Parola incorecta.</p>";
        }
    } else {
        echo "<p style='color:red;'>Utilizatorul nu exista.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Logare - Fisa Auto</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Autentificare</h1>
    </header>
    <main class="container">
        <section class="card">
            <form method="post">
                <label>Email:</label><br>
                <input type="email" name="email" required><br><br>
                <label>Parola:</label><br>
                <input type="password" name="parola" required><br><br>
                <button type="submit">Intra in cont</button>
                <p>Nu ai cont? <a href="register.php">Creeaza unul aici</a></p>
            </form>
        </section>
    </main>
</body>
</html>