<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $marca = $_POST['marca'];
    $model = $_POST['model'];
    $an = $_POST['an'];
    $nr = $_POST['nr_inmatriculare'];
    $vin = $_POST['serie_sasiu'];
    
    $stmt = $conn->prepare("INSERT INTO vehicule (id_utilizator, marca, model, an_fabricatie, nr_inmatriculare, serie_sasiu) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $user_id, $marca, $model, $an, $nr, $vin);

    if ($stmt->execute()) {
        header("Location: index.php");
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Adaugă Vehicul - Fișă Auto</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div style="width: 100px;"></div> 
        <h1>Înregistrare Vehicul Nou</h1>
        <button onclick="location.href='index.php'" class="logout-btn" style="background:#7f8c8d;">Anulează</button>
    </header>
    <main class="container">
        <section class="card">
            <form method="post">
                <label>Marcă:</label>
                <input type="text" name="marca" required>
                
                <label>Model:</label>
                <input type="text" name="model" required>
                
                <label>An Fabricație:</label>
                <input type="number" name="an" required>
                
                <label>Număr Înmatriculare:</label>
                <input type="text" name="nr_inmatriculare" required>
                
                <label>Serie Șasiu (VIN):</label>
                <input type="text" name="serie_sasiu" maxlength="17" required>
                
                <button type="submit">Salvează Vehicul</button>
            </form>
        </section>
    </main>
</body>
</html>