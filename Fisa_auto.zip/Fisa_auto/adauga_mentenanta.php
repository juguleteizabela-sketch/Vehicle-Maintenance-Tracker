<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$id_vehicul = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = $_POST['data'];
    $lucrari = $conn->real_escape_string($_POST['lucrari']);
    $piese = $conn->real_escape_string($_POST['piese']);
    $km = $_POST['km'];
    $cost = $_POST['cost'];
    
    $sql = "INSERT INTO mentenanta_service (id_vehicul, data_interventie, descriere_lucrari, piese_schimbate, cost_total, kilometraj_service) 
            VALUES ('$id_vehicul', '$data', '$lucrari', '$piese', '$cost', '$km')";
    
    $conn->query("UPDATE log_erori SET status = 'rezolvat', data_solutionare = NOW() WHERE id_vehicul = '$id_vehicul' AND status = 'activ'");
    
    if ($conn->query($sql)) { header("Location: index.php"); }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Inregistrare Service</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header><h1>Jurnal Mentenanta</h1></header>
    <main class="container">
        <section class="card">
            <form method="post">
                <label>Data Interventie:</label><br>
                <input type="date" name="data" required><br><br>
                
                <label>Kilometraj:</label><br>
                <input type="number" name="km" required><br><br>
                
                <label>Descriere Lucrari:</label><br>
                <textarea name="lucrari" style="width:100%;" required></textarea><br><br>
                
                <label>Piese Schimbate:</label><br>
                <input type="text" name="piese" style="width:100%;"><br><br>
                
                <label>Cost:</label><br>
                <input type="number" step="0.01" name="cost"><br><br>
                
                <button type="submit">Salveaza in Istoric</button>
            </form>
        </section>
    </main>
</body>
</html>