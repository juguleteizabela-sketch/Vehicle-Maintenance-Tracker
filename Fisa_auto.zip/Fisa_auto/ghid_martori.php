<?php
include 'db.php';
$sql = "SELECT * FROM martori_bord";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Ghid Martori de Bord</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; }
        .martor-card { border: 1px solid #ddd; padding: 15px; border-radius: 8px; background: #fff; text-align: center; }
        .martor-card img { max-width: 80px; margin-bottom: 10px; }
        .warning { color: #c0392b; font-weight: bold; margin-top: 10px; display: block; }
    </style>
</head>
<body>
    <header>
        <h1>Ghid Interactiv Martori Bord</h1>
    </header>
    <main class="container">
        <div class="grid">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='martor-card'>
                            <img src='" . $row["pictograma_url"] . "' alt='Martor'>
                            <h3>" . $row["nume_martor"] . "</h3>
                            <p>" . $row["descriere_tehnica"] . "</p>
                            <span class='warning'>Instructiuni: " . $row["instructiuni_siguranta"] . "</span>
                          </div>";
                }
            }
            ?>
        </div>
        <br>
        <button onclick="location.href='index.php'">Inapoi la Dashboard</button>
    </main>
</body>
</html>