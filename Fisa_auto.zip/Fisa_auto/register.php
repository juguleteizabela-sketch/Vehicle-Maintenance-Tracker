<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nume = $conn->real_escape_string($_POST['nume']);
    $prenume = $conn->real_escape_string($_POST['prenume']);
    $email = $conn->real_escape_string($_POST['email']);
    $parola = password_hash($_POST['parola'], PASSWORD_BCRYPT);

    $sql = "INSERT INTO utilizatori (nume, prenume, email, parola) VALUES ('$nume', '$prenume', '$email', '$parola')";

    if ($conn->query($sql) === TRUE) {
        header("Location: login.php");
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Creare Cont - Fisa Auto</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Creare Cont Nou</h1>
    </header>
    <main class="container">
        <section class="card">
            <form method="post">
                <label>Nume:</label><br>
                <input type="text" name="nume" required><br><br>
                <label>Prenume:</label><br>
                <input type="text" name="prenume" required><br><br>
                <label>Email:</label><br>
                <input type="email" name="email" required><br><br>
                <label>Parola:</label><br>
                <input type="password" name="parola" required><br><br>
                <button type="submit">Inregistrare</button>
                <p>Ai deja cont? <a href="login.php">Logheaza-te aici</a></p>
            </form>
        </section>
    </main>
</body>
</html>