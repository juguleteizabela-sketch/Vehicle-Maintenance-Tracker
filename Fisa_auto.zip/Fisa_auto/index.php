<?php
include 'db.php';

// Protect the page - redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

/**
 * Helper function to calculate fuel efficiency
 * Formula: (Liters / (Current KM - Previous KM)) * 100
 */
function getAverageConsumption($id_v, $conn) {
    $sql = "SELECT km_actuali, litri_alimentati FROM alimentari WHERE id_vehicul = ? ORDER BY data_alimentare DESC LIMIT 2";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_v);
    $stmt->execute();
    $res = $stmt->get_result();
    
    if ($res->num_rows == 2) {
        $n = $res->fetch_assoc();
        $v = $res->fetch_assoc();
        $dist = $n['km_actuali'] - $v['km_actuali'];
        if ($dist > 0) return round(($n['litri_alimentati'] / $dist) * 100, 2);
    }
    return "N/A";
}

// Fetch vehicles with counts for active errors and expiring documents
$sql = "SELECT v.*, 
        (SELECT COUNT(*) FROM log_erori WHERE id_vehicul = v.id_vehicul AND status = 'activ') as erori,
        (SELECT COUNT(*) FROM documente_taxe WHERE id_vehicul = v.id_vehicul AND data_expirare <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)) as alerte
        FROM vehicule v WHERE v.id_utilizator = '$user_id'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Fișă Auto</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Fixed Flexbox Header -->
    <header>
        <div style="width: 100px;"></div> <!-- Counterweight for centering title -->
        <h1>Panou Central de Control</h1>
        <button onclick="location.href='logout.php'" class="logout-btn">Ieșire</button>
    </header>

    <main class="container">
        
        <!-- Notification Center -->
        <?php
        $notificari = $conn->query("SELECT d.*, v.marca FROM documente_taxe d JOIN vehicule v ON d.id_vehicul = v.id_vehicul WHERE v.id_utilizator = '$user_id' AND d.data_expirare <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)");
        if ($notificari->num_rows > 0): ?>
            <section class="card" style="border-left: 5px solid #e67e22; margin-bottom: 20px; background: #fffaf5;">
                <h3 style="margin-top:0;">🔔 Alerte Documente</h3>
                <ul style="margin-bottom:0;">
                    <?php while($n = $notificari->fetch_assoc()): ?>
                        <li><strong><?php echo $n['marca']; ?></strong>: <?php echo $n['tip_document']; ?> expiră pe <?php echo $n['data_expirare']; ?>.</li>
                    <?php endwhile; ?>
                </ul>
            </section>
        <?php endif; ?>

        <!-- Global Quick Actions -->
        <section class="quick-actions">
            <button onclick="location.href='adauga_vehicul.php'">+ Vehicul Nou</button>
            <button onclick="location.href='ghid_martori.php'">Ghid Martori</button>
            <button onclick="location.href='adauga_alimentare.php'">+ Alimentare</button>
        </section>

        <!-- Vehicle Fleet Display -->
        <?php if ($result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()): ?>
                <section class="card" style="margin-bottom:20px;">
                    <div style="display:flex; justify-content:space-between; align-items: flex-start;">
                        <div>
                            <h2 style="margin:0;"><?php echo $row['marca'] . " " . $row['model']; ?></h2>
                            <p style="color:#7f8c8d; margin:5px 0;">VIN: <code><?php echo $row['serie_sasiu']; ?></code></p>
                            <p>Nr: <strong><?php echo $row['nr_inmatriculare']; ?></strong></p>
                        </div>
                        <div style="text-align:right;">
                            <span class="stat-badge">Consum: <?php echo getAverageConsumption($row['id_vehicul'], $conn); ?> L/100km</span>
                        </div>
                    </div>

                    <!-- Interactive Action Grid -->
                    <div class="grid-links" style="margin-top:20px; display:grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap:10px;">
                        <a href="documente.php?id=<?php echo $row['id_vehicul']; ?>" class="action-link">
                            📅 Taxe (<?php echo $row['alerte']; ?>)
                        </a>

                        <a href="statistici.php?id=<?php echo $row['id_vehicul']; ?>" class="action-link" style="background:#f39c12; color:white; border-color:#f39c12;">
                            📊 Statistici
                        </a>

                        <a href="logheaza_eroare.php?id=<?php echo $row['id_vehicul']; ?>" class="action-link" <?php if($row['erori'] > 0) echo 'style="border-color:#e74c3c; color:#e74c3c; font-weight:bold;"'; ?>>
                            ⚠️ Erori: <?php echo $row['erori']; ?>
                        </a>

                        <a href="adauga_mentenanta.php?id=<?php echo $row['id_vehicul']; ?>" class="action-link">
                            🔧 Service
                        </a>

                        <a href="pasaport_digital.php?vin=<?php echo $row['serie_sasiu']; ?>" class="action-link" style="background:#27ae60; color:white; border-color:#27ae60;">
                            📜 Pașaport
                        </a>

                        <a href="javascript:void(0);" onclick="confirmDelete(<?php echo $row['id_vehicul']; ?>)" class="action-link" style="background:#c0392b; color:white; border-color:#c0392b;">
                            🗑️ Șterge
                        </a>
                    </div>
                </section>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="text-align:center; color:#7f8c8d; margin-top:50px;">Nu ai niciun vehicul adăugat. Folosește butonul de mai sus pentru a începe.</p>
        <?php endif; ?>
    </main>

    <!-- Global Scripts -->
    <script>
    function confirmDelete(id) {
        if (confirm("ATENȚIE: Ștergerea vehiculului va elimina definitiv toate datele asociate (alimentări, service, taxe). Continuați?")) {
            window.location.href = "sterge_vehicul.php?id=" + id;
        }
    }
    </script>
</body>
</html>