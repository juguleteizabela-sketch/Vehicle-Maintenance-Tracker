<?php
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_v = $_POST['id_vehicul'];
    $data = $_POST['data_alimentare'];
    $km = $_POST['km_actuali'];
    $litri = $_POST['litri_alimentati'];
    $cost = $_POST['cost_total'];

    $stmt_check = $conn->prepare("SELECT MAX(km_actuali) as max_km FROM alimentari WHERE id_vehicul = ?");
    $stmt_check->bind_param("i", $id_v);
    $stmt_check->execute();
    $res_check = $stmt_check->get_result();
    $row_check = $res_check->fetch_assoc();
    $last_km = $row_check['max_km'] ?? 0;

    if ($km <= $last_km) {
        $error_message = "Eroare: Kilometrajul introdus ($km) trebuie să fie mai mare decât cel anterior ($last_km).";
    } else {
        $stmt = $conn->prepare("INSERT INTO alimentari (id_vehicul, data_alimentare, km_actuali, litri_alimentati, cost_total) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isidd", $id_v, $data, $km, $litri, $cost);

        if ($stmt->execute()) {
            header("Location: index.php");
            exit();
        } else {
            $error_message = "A apărut o eroare la salvarea datelor.";
        }
    }
}

$vehicule = $conn->query("SELECT id_vehicul, marca, model FROM vehicule WHERE id_utilizator = '$user_id'");
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Adaugă Alimentare - Fișă Auto</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div style="width: 100px;"></div> 
        <h1>Adaugă Bon Combustibil</h1>
        <button onclick="location.href='index.php'" class="logout-btn" style="background:#7f8c8d;">Anulează</button>
    </header>

    <main class="container">
        <section class="card">
            <?php if ($error_message): ?>
                <p style="color: #c0392b; font-weight: bold;"><?php echo $error_message; ?></p>
            <?php endif; ?>

            <form method="post">
                <label>Selectează Vehicul:</label>
                <select name="id_vehicul" required>
                    <?php while($v = $vehicule->fetch_assoc()): ?>
                        <option value="<?php echo $v['id_vehicul']; ?>">
                            <?php echo $v['marca'] . " " . $v['model']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>

                <label>Data Alimentării:</label>
                <input type="date" name="data_alimentare" value="<?php echo date('Y-m-d'); ?>" required>

                <label>Kilometraj Actual (KM):</label>
                <input type="number" name="km_actuali" placeholder="Ex: 45000" required>

                <label>Litri Alimentați (L):</label>
                <input type="number" step="0.01" name="litri_alimentati" placeholder="Ex: 45.50" required>

                <label>Cost Total (RON):</label>
                <input type="number" step="0.01" name="cost_total" placeholder="Ex: 320.00" required>

                <button type="submit">Salvează Alimentarea</button>
            </form>
        </section>
    </main>
</body>
</html>