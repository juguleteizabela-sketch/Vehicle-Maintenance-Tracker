<?php
include 'db.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$id_v = $_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tip = $_POST['tip_document'];
    $data = $_POST['data_expirare'];
    
    $sql = "INSERT INTO documente_taxe (id_vehicul, tip_document, data_expirare) 
            VALUES ('$id_v', '$tip', '$data') 
            ON DUPLICATE KEY UPDATE data_expirare = '$data', alerta_trimisa = 0";
    
    if ($conn->query($sql)) { header("Location: index.php"); }
}

$docs = $conn->query("SELECT * FROM documente_taxe WHERE id_vehicul = '$id_v'");
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Management Documente</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header><h1>Documente Legale si Taxe</h1></header>
    <main class="container">
        <section class="card">
            <h3>Actualizare Documente</h3>
            <form method="post">
                <label>Tip Document:</label><br>
                <select name="tip_document" required>
                    <option value="RCA">RCA</option>
                    <option value="ITP">ITP</option>
                    <option value="Rovinieta">Rovinieta</option>
                </select><br><br>
                
                <label>Data Expirarii:</label><br>
                <input type="date" name="data_expirare" required><br><br>
                
                <button type="submit">Salveaza Data</button>
            </form>
        </section>

        <section class="card" style="margin-top:20px;">
            <h3>Documente Active</h3>
            <table>
                <thead><tr><th>Tip</th><th>Expira la</th><th>Status</th></tr></thead>
                <tbody>
                    <?php while($d = $docs->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $d['tip_document']; ?></td>
                            <td><?php echo $d['data_expirare']; ?></td>
                            <td>
                                <?php 
                                    $zile = (strtotime($d['data_expirare']) - time()) / 86400;
                                    echo $zile < 0 ? "<span style='color:red;'>Expirat</span>" : round($zile) . " zile rămase";
                                ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </section>
        <br><button onclick="location.href='index.php'">Inapoi</button>
    </main>
</body>
</html>