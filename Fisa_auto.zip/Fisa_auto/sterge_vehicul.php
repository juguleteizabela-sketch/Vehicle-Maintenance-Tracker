<?php
include 'db.php';
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $user_id = $_SESSION['user_id'];
    // Ensures users can only delete their own cars
    $stmt = $conn->prepare("DELETE FROM vehicule WHERE id_vehicul = ? AND id_utilizator = ?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
}
header("Location: index.php");