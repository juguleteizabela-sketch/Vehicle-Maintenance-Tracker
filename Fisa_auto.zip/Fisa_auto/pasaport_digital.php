<?php
include 'db.php';

// Check if VIN is provided in the URL
if (!isset($_GET['vin'])) { die("Serie sasiu lipsa."); }
$vin = $_GET['vin'];

// Fetch Vehicle Info
$stmt = $conn->prepare("SELECT v.*, u.nume, u.prenume FROM vehicule v JOIN utilizatori u ON v.id_utilizator = u.id_utilizator WHERE v.serie_sasiu = ?");
$stmt->bind_param("s", $vin);
$stmt->execute();
$car = $stmt->get_result()->fetch_assoc();

if (!$car) { die("Vehiculul nu a fost gasit in baza de date."); }

$id_v = $car['id_vehicul'];

// Fetch Service History[cite: 1]
$history = $conn->query("SELECT * FROM mentenanta_service WHERE id_vehicul = $id_v ORDER BY data_interventie DESC");

// Fetch Resolved Errors[cite: 1]
$faults = $conn->query("SELECT l.*, m.nume_martor FROM log_erori l JOIN martori_bord m ON l.id_martor = m.id_martor WHERE l.id_vehicul = $id_v ORDER BY data_aparitie DESC");
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Pașaport Digital - <?php echo $vin; ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .cert-stamp { border: 3px solid #27ae60; color: #27ae60; padding: 10px; display: inline-block; transform: rotate(-5deg); font-weight: bold; margin-bottom: 20px; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>
    <header>
        <div style="width: 100px;"></div> 
        <h1>Pașaport Digital Vehicul</h1>
        <button onclick="window.print()" class="logout-btn no-print">Printează / PDF</button>
    </header>
    <main class="container">
        <section class="card">
            <div class="cert-stamp">ISTORIC CERTIFICAT</div>
            <h2>Detalii Vehicul: <?php echo $car['marca'] . " " . $car['model']; ?></h2>
            <p><strong>Proprietar:</strong> <?php echo $car['nume'] . " " . $car['prenume']; ?></p>
            <p><strong>Serie Șasiu (VIN):</strong> <code><?php echo $car['serie_sasiu']; ?></code></p>
            <p><strong>Număr Înmatriculare:</strong> <?php echo $car['nr_inmatriculare']; ?></p>
        </section>

        <section class="card" style="margin-top:20px;">
            <h3>Cronologie Mentenanță și Revizii</h3>
            <table>
                <thead>
                    <tr>
                        <th>Data</th>
                        <th>KM</th>
                        <th>Intervenție</th>
                        <th>Piese</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($s = $history->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $s['data_interventie']; ?></td>
                            <td><?php echo $s['kilometraj_service']; ?></td>
                            <td><?php echo $s['descriere_lucrari']; ?></td>
                            <td><?php echo $s['piese_schimbate']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </section>

        <section class="card" style="margin-top:20px;">
            <h3>Istoric Diagnoză și Erori Soluționate</h3>
            <ul>
                <?php while($f = $faults->fetch_assoc()): ?>
                    <li>
                        <strong><?php echo $f['data_aparitie']; ?>:</strong> 
                        <?php echo $f['nume_martor']; ?> - 
                        <span style="color:<?php echo $f['status'] == 'activ' ? 'red' : 'green'; ?>">
                            <?php echo strtoupper($f['status']); ?>
                        </span>
                        <?php if ($f['data_solutionare']) echo " (Soluționat la: " . $f['data_solutionare'] . ")"; ?>
                    </li>
                <?php endwhile; ?>
            </ul>
        </section>
    </main>
</body>
</html>