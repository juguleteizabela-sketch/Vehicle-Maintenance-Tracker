-- 1. Create the Database
CREATE DATABASE IF NOT EXISTS fisa_auto_bord;
USE fisa_auto_bord;

-- 2. Users Table (Proprietari/Administratori)
CREATE TABLE utilizatori (
    id_utilizator INT AUTO_INCREMENT PRIMARY KEY,
    nume VARCHAR(50) NOT NULL,
    prenume VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE, -- Ensures one account per email
    parola VARCHAR(255) NOT NULL, -- For hashed passwords
    data_creare TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Vehicles Table (Management Vehicul)
CREATE TABLE vehicule (
    id_vehicul INT AUTO_INCREMENT PRIMARY KEY,
    id_utilizator INT NOT NULL,
    marca VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    an_fabricatie INT,
    nr_inmatriculare VARCHAR(15) NOT NULL UNIQUE,
    serie_sasiu VARCHAR(17) NOT NULL UNIQUE, -- VIN must be unique for history certification
    FOREIGN KEY (id_utilizator) REFERENCES utilizatori(id_utilizator) ON DELETE CASCADE
);

-- 4. Warning Lights Dictionary (Ghid Martori de Bord)
CREATE TABLE martori_bord (
    id_martor INT AUTO_INCREMENT PRIMARY KEY,
    nume_martor VARCHAR(50) NOT NULL,
    descriere_tehnica TEXT,
    instructiuni_siguranta TEXT, -- Vital for the "Safety & Prevention" objective
    pictograma_url VARCHAR(255) -- Path to the dashboard icon image
);

-- 5. Error Logs (Monitorizare Defectiuni)
CREATE TABLE log_erori (
    id_log INT AUTO_INCREMENT PRIMARY KEY,
    id_vehicul INT NOT NULL,
    id_martor INT NOT NULL,
    data_aparitie DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_solutionare DATETIME NULL, -- NULL until the repair is confirmed
    status ENUM('activ', 'rezolvat') DEFAULT 'activ',
    descriere_proprietar TEXT,
    FOREIGN KEY (id_vehicul) REFERENCES vehicule(id_vehicul) ON DELETE CASCADE,
    FOREIGN KEY (id_martor) REFERENCES martori_bord(id_martor)
);

-- 6. Legal Documents (RCA, ITP, Rovinieta)
CREATE TABLE documente_taxe (
    id_document INT AUTO_INCREMENT PRIMARY KEY,
    id_vehicul INT NOT NULL,
    tip_document ENUM('RCA', 'ITP', 'Rovinieta') NOT NULL,
    data_expirare DATE NOT NULL,
    alerta_trimisa BOOLEAN DEFAULT FALSE, -- Used for the automated notification system
    FOREIGN KEY (id_vehicul) REFERENCES vehicule(id_vehicul) ON DELETE CASCADE
);

-- 7. Fuel Consumption (Alimentari & Statistici)
CREATE TABLE alimentari (
    id_alimentare INT AUTO_INCREMENT PRIMARY KEY,
    id_vehicul INT NOT NULL,
    data_alimentare DATE NOT NULL,
    km_actuali INT NOT NULL, -- Required to calculate L/100km statistics
    litri_alimentati DECIMAL(10, 2) NOT NULL,
    cost_total DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (id_vehicul) REFERENCES vehicule(id_vehicul) ON DELETE CASCADE
);

-- 8. Maintenance History (Status Mentenanta / Certificare)
CREATE TABLE mentenanta_service (
    id_service INT AUTO_INCREMENT PRIMARY KEY,
    id_vehicul INT NOT NULL,
    data_interventie DATE NOT NULL,
    descriere_lucrari TEXT NOT NULL,
    piese_schimbate TEXT,
    cost_total DECIMAL(10, 2),
    kilometraj_service INT,
    FOREIGN KEY (id_vehicul) REFERENCES vehicule(id_vehicul) ON DELETE CASCADE
);
INSERT INTO martori_bord (nume_martor, descriere_tehnica, instructiuni_siguranta, pictograma_url) VALUES
('Sistem Directie', 'Defectiune la sistemul de servodirectie.', 'Trageti pe dreapta in siguranta. Manevrarea volanului va necesita un efort mult mai mare. Vizitati un service.', 'img/steering.png'),
('ABS (Sistem Anti-blocare)', 'Sistemul ABS a detectat o defectiune si a fost dezactivat.', 'Franarea mecanica functioneaza normal, dar rotile se pot bloca la franari de urgenta. Adaptati viteza.', 'img/abs.png'),
('Control Stabilitate (ESC)', 'Sistemul de control al stabilitatii este dezactivat sau prezinta o eroare.', 'Conduceti cu prudenta sporita, in special pe carosabil umed sau alunecos.', 'img/esc.png'),
('Bujii Incandescente', 'Bujiile se incalzesc (aprins continuu) sau exista o eroare la sistem (intermitent).', 'Asteptati stingerea martorului inainte de a porni motorul. Daca clipeste, necesita diagnoza.', 'img/glow_plug.png'),
('Nivel Carburant Scazut', 'Nivelul de combustibil a ajuns la rezerva minima.', 'Alimentati cat mai curand la cea mai apropiata statie pentru a evita defectarea pompei de combustibil.', 'img/fuel.png'),
('Lichid Parbriz', 'Nivelul lichidului de spalare a parbrizului este scazut.', 'Completati cu lichid de parbriz adecvat sezonului curent.', 'img/washer.png'),
('AdBlue / Emisii', 'Nivelul de AdBlue este scazut sau exista o eroare la sistemul SCR.', 'Completati cu AdBlue. Daca rezervorul se goleste complet, motorul nu va mai reporni.', 'img/adblue.png'),
('Supraincalzire Motor', 'Temperatura lichidului de racire a depasit limita admisa.', 'OPRITI IMEDIAT! Pericol major de distrugere a motorului. Nu deschideti capacul vasului de expansiune cat timp motorul este fierbinte.', 'img/overheat.png'),
('Presiune Ulei', 'Presiunea uleiului de motor este sub limita de siguranta.', 'OPRITI IMEDIAT MOTORUL! Functionarea in continuare va duce la griparea si distrugerea totala a motorului. Verificati nivelul uleiului.', 'img/oil.png'),
('Incarcare Baterie', 'Alternatorul nu mai incarca bateria vehiculului.', 'Opriti consumatorii neesentiali (AC, radio, incalzire scaune) si mergeti imediat la un service. Motorul se va opri cand bateria se descarca.', 'img/battery.png'),
('Presiune Pneuri', 'Senzorii au detectat o scadere a presiunii intr-una sau mai multe anvelope.', 'Reduceti viteza si verificati presiunea la prima statie peco. Dupa remediere, resetati sistemul din meniu.', 'img/tire.png'),
('Placute Frana', 'Senzorul de uzura indica faptul ca placutele de frana trebuie inlocuite.', 'Programati o vizita la service in cel mai scurt timp pentru inlocuirea placutelor. Capacitatea de franare va scadea treptat.', 'img/brake_pads.png'),
('Filtru Particule', 'Filtrul DPF este incarcat cu funingine si necesita regenerare.', 'Conduceti constant la o turatie de peste 2500 RPM timp de aproximativ 15-20 de minute pana se stinge martorul.', 'img/dpf.png'),
('Sistem Airbag', 'Defectiune in sistemul de airbag-uri sau la pretensionoarele centurilor de siguranta.', 'Airbag-urile ar putea sa nu se declanseze in caz de accident. Necesita verificare la un service autorizat.', 'img/airbag.png');