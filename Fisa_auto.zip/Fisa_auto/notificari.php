<?php
include 'db.php';

// Select documents expiring in the next 30 days that haven't sent an alert yet
$sql = "SELECT d.*, v.marca, v.model, u.email 
        FROM documente_taxe d 
        JOIN vehicule v ON d.id_vehicul = v.id_vehicul 
        JOIN utilizatori u ON v.id_utilizator = u.id_utilizator 
        WHERE d.data_expirare <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) 
        AND d.alerta_trimisa = 0";

$result = $conn->query($sql);

while($row = $result->fetch_assoc()) {
    $to = $row['email'];
    $subject = "Alertă Expirare: " . $row['tip_document'];
    $message = "Documentul " . $row['tip_document'] . " pentru " . $row['marca'] . " expira la " . $row['data_expirare'] . ".";
    
    // In a real server, use mail($to, $subject, $message);
    if(true) { 
        echo "Email trimis catre " . $to . " pentru " . $row['tip_document'] . "<br>";
        $conn->query("UPDATE documente_taxe SET alerta_trimisa = 1 WHERE id_document = " . $row['id_document']);
    }
}
?>